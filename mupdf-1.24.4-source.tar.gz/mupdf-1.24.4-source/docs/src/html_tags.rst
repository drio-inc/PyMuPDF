.. |instance_props| raw:: html

   <span class="instance_props_tag">Instance properties</span>


.. |instance_methods| raw:: html

   <span class="instance_methods_tag">Instance methods</span>


.. |example_tag| raw:: html

   <span class="example_tag">EXAMPLE</span>


.. |mutool_tag| raw:: html

   <span class="mutool_tag">mutool only</span>

.. |mutool_tag_wasm_soon| raw:: html

   <span class="mutool_tag">mutool only</span>


.. |wasm_tag| raw:: html

   <span class="wasm_tag">wasm only</span>


.. |tor_todo| raw:: html

   <span class="wasm_tag" style="background:#cc0000;color:black;font-size:20px;">Tor TODO</span>

.. |jamie_todo| raw:: html

   <span class="wasm_tag" style="background:#cc00cc;color:black;font-size:20px;">Jamie TODO</span>